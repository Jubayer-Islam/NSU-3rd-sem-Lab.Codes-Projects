
package lab11_q2;


public class Lab11_Q2 {

   
    public static void main(String[] args) {
        
        PercentageDiscount p= new PercentageDiscount(30);
        
        System.out.println("Discounted perice: "+p.discountable(100));
    }
    
}
