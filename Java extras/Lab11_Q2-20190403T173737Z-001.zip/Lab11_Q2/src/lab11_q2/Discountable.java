
package lab11_q2;

public interface Discountable {
    double discountable(double price);
}
