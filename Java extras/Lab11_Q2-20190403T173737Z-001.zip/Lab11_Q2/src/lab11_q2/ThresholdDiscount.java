
package lab11_q2;


public class ThresholdDiscount implements Discountable {
    
}
